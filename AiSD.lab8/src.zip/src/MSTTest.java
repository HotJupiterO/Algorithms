import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class MSTTest {

    @BeforeEach
    void setUp() {

    }

    @Test
    void primMST() {

    }
}